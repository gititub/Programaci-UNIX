#! /bin/bash

cd /home/pscramartinezsequ/
echo " 
•El camp amb l'identificador (user) sigui major o igual a 10 i menor que 99.
•Sigui relatiu exclusivament a dones (sexe femení)
•Edat compresa entre els rangs d'edat de 10 a 19 anys i de 30 a 39, ambdós inclusivament.
•La llengua nativa sigui el finlandès i a més sàpiguen també parlar l'espanyol i el francès";
grep -E '(^[1-9][0-9],F,[13][0-9],finnish,).*(french.*spanish|spanish.*french)' demographic_info.csv;


