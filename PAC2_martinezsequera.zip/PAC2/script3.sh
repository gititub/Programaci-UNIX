#! /bin/bash

cd /home/pscramartinezsequ/liver/
echo "Albumin=3"
echo Age sex Albumin Proteins
echo "****************";


echo "Women";
echo "-------------";
head female2.csv;
echo "Men"
echo "------------";
cat male2.csv;

